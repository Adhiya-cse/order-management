# B2B Order Management Platform

A demo distributor portal for product catalog, stock status, order creation, invoices, and admin controls.

## Beginner-friendly setup

**Prerequisites:** Node.js 20 LTS (or another current supported Node.js release), npm, and VS Code.

1. Extract this folder.
2. Open this project folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000` in your browser.
7. Stop the server with `Ctrl+C`.

The first start creates `data.sqlite`, applies the SQL schema/migrations, and inserts sample records. Sample data uses fictional names and `.test` / example.test addresses.

## Features

- Product catalog and stock visibility
- Create orders with stock validation
- Order status management (admin demo role)
- Invoice JSON endpoint
- Audit log endpoint restricted to admin demo role

## Roles

The role selector sends a demo role header to the API. It demonstrates authorization checks for coursework, **not production authentication**. Anyone who can change their browser request can choose a role. A production app needs verified login, hashed passwords, secure sessions/JWT, authorization tests, HTTPS, and secret management.

## API quick reference

- `GET /api/health` — server health
- `GET /api/products`
- `POST /api/products (admin)`
- `POST /api/orders`
- `GET /api/orders`
- `PATCH /api/orders/:id/status (admin)`
- `GET /api/invoices/:id`
- `GET /api/audit (admin)`

For JSON requests use `Content-Type: application/json`. The browser UI adds the selected demo role automatically.

## Database

SQLite is a relational database. Schema creation runs at server startup using `CREATE TABLE IF NOT EXISTS`; this is the starter migration strategy for this demo. Foreign keys are enabled where applicable. Keep `data.sqlite` out of Git if it contains anything other than disposable demo data.

## Validation and testing

See [`docs/TEST_PLAN.md`](docs/TEST_PLAN.md) and [`docs/REQUIREMENTS.md`](docs/REQUIREMENTS.md). Manual tests are written as a reproducible checklist. Do not report tests as passed until you have run them locally and recorded the actual result.

## Known limitations

- Demo role selector is not secure authentication.
- No production deployment, email notifications, rate limiting, CSRF controls, or monitoring configured.
- SQLite is suitable for a small demo, not a claim of production-scale capacity.
- UI is intentionally vanilla HTML/CSS/JavaScript to keep setup manageable for a beginner.


## Submission checklist

- [ ] Run the app and verify the main workflows.
- [ ] Capture screenshots of the dashboard and successful/invalid cases.
- [ ] Update the work log with the actual date/time and actions completed.
- [ ] Commit source and docs to a Git repository.
- [ ] Be ready to explain the schema, API validation, role checks, and limitations.
