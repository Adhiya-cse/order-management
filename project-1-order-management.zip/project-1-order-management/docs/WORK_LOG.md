# Work log

> Replace the placeholders with your actual dates and actions. Do not claim work or tests you did not perform.

| Date/time | Activity | Evidence / outcome | Next action |
|---|---|---|---|
| YYYY-MM-DD HH:MM | Reviewed assignment and requirements | Requirements document created | Run local app |
| YYYY-MM-DD HH:MM | Installed dependencies and started server | Record actual terminal result | Exercise main workflows |
| YYYY-MM-DD HH:MM | Executed test plan | Update each test with actual outcome | Fix issues and capture screenshots |
