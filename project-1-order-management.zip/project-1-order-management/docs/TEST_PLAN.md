# Test plan — B2B Order Management Platform

Record your real results in the table below after running each case. Do not leave a test marked PASS unless you observed it.

| ID | Test | Expected result | Actual result |
|---|---|---|---|
| T1 | Open the home page | Dashboard and sample products render | Not run |
| T2 | Create a valid order | Order is stored and stock decreases | Not run |
| T3 | Order more units than available | API/UI displays validation error and stock is unchanged | Not run |
| T4 | Create product as Employee / Viewer | 403 authorization error | Not run |
| T5 | Create product as Admin with unique SKU | Product appears in catalog | Not run |
| T6 | Request an invoice for an existing order | Invoice details are returned | Not run |
| T7 | Check API health | JSON response reports status ok | Not run |
## How to run

1. Start the app with `npm start`.
2. Use the UI for normal cases.
3. For authorization/error cases, use the role picker and forms.
4. If using a direct API client, include `Content-Type: application/json` and `x-role: admin` / `x-role: agent` as applicable.
5. Record date, result, and any defect in `WORK_LOG.md`.

## Evidence to capture
- Main dashboard with sample records.
- One successful create/update flow.
- One rejected invalid-input case.
- One rejected unauthorized action.
- Browser console/server terminal if errors occur.
