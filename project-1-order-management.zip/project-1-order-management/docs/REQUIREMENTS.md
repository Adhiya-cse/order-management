# Requirements — B2B Order Management Platform

## Problem and stakeholder
A demo distributor portal for product catalog, stock status, order creation, invoices, and admin controls. Primary stakeholders are the simulated operations/admin team and the end users who create or review records.

## Scope
- Product catalog and stock visibility
- Create orders with stock validation
- Order status management (admin demo role)
- Invoice JSON endpoint
- Audit log endpoint restricted to admin demo role

## Out of scope
- Real customer or employee data
- Production identity provider and enterprise SSO
- External payment processing, where applicable
- Production hosting, alerting, and high-availability setup

## Assumptions
- This is a local, portfolio-oriented demonstration.
- All seeded records are fictional.
- The role picker is for demonstrating authorization paths only.
- Success means core flows work locally, invalid input is rejected, data persists in SQLite, and the reviewer can reproduce the setup from the README.

## Acceptance criteria
1. Product list loads from SQLite
1. Invalid product or quantity is rejected
1. Orders reduce stock transactionally
1. Non-admin cannot create products or change order status
1. Invoice endpoint returns order details

## Architecture
- Browser: semantic HTML, CSS, vanilla JavaScript.
- Server: Node.js + Express REST endpoints.
- Database: SQLite relational tables with startup schema creation.
- Validation: server-side checks for required fields, numeric bounds, enums, and uniqueness constraints.
- Audit: records selected create/update actions.

## Quality measures
- Functional: run the checklist in `TEST_PLAN.md`.
- Data integrity: check constraints, uniqueness, transactions where multiple records must change together.
- Reproducibility: fresh install and launch using README steps.
- Security limitations: demo roles are not real authentication; disclose this in demos.
