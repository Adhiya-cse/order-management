# Demo and viva notes — B2B Order Management Platform

## 60-second explanation
This project demonstrates a full-stack workflow for a simulated business problem. The browser sends requests to an Express REST API, the API validates input and checks the selected demo role for protected actions, and SQLite stores relational records. I included sample data, error handling, an audit log for selected actions, a reproducible setup guide, and a manual test plan.

## Key decisions
- Used vanilla JavaScript to keep the client simple for a beginner.
- Used Express to expose REST endpoints.
- Used SQLite for local relational persistence and easy review.
- Added server-side validation rather than relying only on browser validation.
- Marked role selection as a demo only and documented production security gaps.

## Viva questions and prompts
1. **What problem does it solve?** Explain the simulated stakeholder workflow and the main records managed.
2. **How does the UI communicate with the backend?** The browser uses `fetch()` to call `/api/...` REST endpoints with JSON.
3. **How is data stored?** SQLite tables and constraints; schema is initialized at server startup.
4. **How did you validate it?** Run the documented test plan and report observed results, not assumptions.
5. **What are the limitations?** Demo role header is not secure authentication; no production deployment or monitoring.
6. **How would you scale it?** Add real identity, structured migrations, automated tests, logging/monitoring, deployment pipeline, backups, and consider PostgreSQL for multi-user production needs.

## Honest demo checklist
- [ ] Show the primary workflow.
- [ ] Show one validation failure.
- [ ] Show the database persists data after restart.
- [ ] Show role-gated action using allowed and disallowed roles.
- [ ] Explain at least two limitations and next steps.
