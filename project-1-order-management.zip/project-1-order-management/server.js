const express = require('express');
const path = require('path');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, 'data.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Database migration: create tables if they do not exist.
db.exec(`
CREATE TABLE IF NOT EXISTS products (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 sku TEXT NOT NULL UNIQUE,
 price REAL NOT NULL CHECK(price >= 0),
 stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 customer_name TEXT NOT NULL,
 items_json TEXT NOT NULL,
 total REAL NOT NULL CHECK(total >= 0),
 status TEXT NOT NULL DEFAULT 'Pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_log (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 actor TEXT NOT NULL,
 action TEXT NOT NULL,
 details TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const count = db.prepare('SELECT COUNT(*) AS n FROM products').get().n;
if (!count) {
 const add = db.prepare('INSERT INTO products(name, sku, price, stock) VALUES (?, ?, ?, ?)');
 [
  ['Wireless Mouse','WM-100',599,24],
  ['USB-C Hub','UCH-210',1499,12],
  ['Mechanical Keyboard','MK-300',2799,8],
  ['Laptop Stand','LS-120',899,18]
 ].forEach(p => add.run(...p));
}


app.use(express.json({limit:'100kb'}));
app.use(express.static(path.join(__dirname,'public')));

// Demo identity only: select a role in the UI. Replace with real authentication before production.
app.use((req,res,next) => { req.role = String(req.header('x-role') || 'employee').toLowerCase(); next(); });
function requireRole(role) {
 return (req,res,next) => req.role === role ? next() : res.status(403).json({error:`This action requires the ${role} demo role.`});
}
function audit(actor,action,details) {
 db.prepare('INSERT INTO audit_log(actor,action,details) VALUES(?,?,?)').run(actor,action,details);
}

app.get('/api/products', (req,res) => res.json(db.prepare('SELECT * FROM products ORDER BY id DESC').all()));
app.post('/api/products', requireRole('admin'), (req,res) => {
 const {name,sku,price,stock} = req.body;
 if (!name || !sku || !Number.isFinite(Number(price)) || Number(price)<0 || !Number.isInteger(Number(stock)) || Number(stock)<0) return res.status(400).json({error:'Enter name, SKU, non-negative price and whole-number stock.'});
 try {
  const result = db.prepare('INSERT INTO products(name,sku,price,stock) VALUES(?,?,?,?)').run(name.trim(),sku.trim(),Number(price),Number(stock));
  audit(req.role,'PRODUCT_CREATED',`Product ${sku} created`);
  res.status(201).json(db.prepare('SELECT * FROM products WHERE id=?').get(result.lastInsertRowid));
 } catch(e) { res.status(400).json({error:'SKU must be unique.'}); }
});
app.post('/api/orders', (req,res) => {
 const {customerName, items} = req.body;
 if (!customerName?.trim() || !Array.isArray(items) || !items.length) return res.status(400).json({error:'Customer name and at least one item are required.'});
 const create = db.transaction(() => {
  let total=0; const normalized=[];
  for (const item of items) {
   const p=db.prepare('SELECT * FROM products WHERE id=?').get(Number(item.productId));
   const qty=Number(item.quantity);
   if (!p || !Number.isInteger(qty) || qty<1) throw new Error('Invalid product or quantity.');
   if (p.stock<qty) throw new Error(`Insufficient stock for ${p.name}.`);
   total += p.price*qty; normalized.push({productId:p.id,name:p.name,price:p.price,quantity:qty});
  }
  for (const i of normalized) db.prepare('UPDATE products SET stock=stock-? WHERE id=?').run(i.quantity,i.productId);
  const result=db.prepare('INSERT INTO orders(customer_name,items_json,total,status) VALUES(?,?,?,?)').run(customerName.trim(),JSON.stringify(normalized),total,'Pending');
  audit(req.role,'ORDER_CREATED',`Order ${result.lastInsertRowid} total ${total.toFixed(2)}`);
  return db.prepare('SELECT * FROM orders WHERE id=?').get(result.lastInsertRowid);
 });
 try { const order=create(); res.status(201).json({...order,items:JSON.parse(order.items_json)}); }
 catch(e) { res.status(400).json({error:e.message}); }
});
app.get('/api/orders', (req,res) => res.json(db.prepare('SELECT * FROM orders ORDER BY id DESC').all().map(o=>({...o,items:JSON.parse(o.items_json)}))));
app.patch('/api/orders/:id/status', requireRole('admin'), (req,res) => {
 const allowed=['Pending','Processing','Shipped','Cancelled'];
 if (!allowed.includes(req.body.status)) return res.status(400).json({error:'Unsupported status.'});
 const result=db.prepare('UPDATE orders SET status=? WHERE id=?').run(req.body.status,Number(req.params.id));
 if (!result.changes) return res.status(404).json({error:'Order not found.'});
 audit(req.role,'ORDER_STATUS_CHANGED',`Order ${req.params.id} => ${req.body.status}`);
 res.json(db.prepare('SELECT * FROM orders WHERE id=?').get(Number(req.params.id)));
});
app.get('/api/invoices/:id', (req,res) => {
 const o=db.prepare('SELECT * FROM orders WHERE id=?').get(Number(req.params.id));
 if (!o) return res.status(404).json({error:'Order not found.'});
 res.json({invoiceNumber:`INV-${String(o.id).padStart(5,'0')}`,orderId:o.id,customerName:o.customer_name,items:JSON.parse(o.items_json),total:o.total,status:o.status,createdAt:o.created_at});
});
app.get('/api/audit', requireRole('admin'), (req,res) => res.json(db.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT 100').all()));


app.get('/api/health', (req,res) => res.json({status:'ok',project:'B2B Order Management Platform'}));
app.use((err,req,res,next) => {
 console.error(err);
 res.status(500).json({error:'Unexpected server error.'});
});
app.listen(PORT, () => console.log(`B2B Order Management Platform running at http://localhost:${PORT}`));
