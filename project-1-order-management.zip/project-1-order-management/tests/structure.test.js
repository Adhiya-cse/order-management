const test = require('node:test');
const assert = require('node:assert/strict');

test('project has required app files', () => {
 const fs = require('node:fs');
 const path = require('node:path');
 for (const f of ['server.js','package.json','README.md','public/index.html','public/app.js','public/styles.css','docs/REQUIREMENTS.md','docs/TEST_PLAN.md']) {
  assert.equal(fs.existsSync(path.join(__dirname,'..',f)), true, `Missing ${f}`);
 }
});
